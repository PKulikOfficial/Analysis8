#This file is only here to setup the program before launching it for the first time.
#It creates the necessary database,tables and superadmin account for the program to function correctly
#This file is created for the developer and teachers to quickly reset the database to the initial state (empty with only a superadmin account)
import sqlite3
import time
import os.path
from utils.misc.clear_console import clear_console
from utils.encryption.encrypt import encrypt
from utils.encryption.encrypt import encryptTupleListSpecificItems
from datetime import date

def initialize():
    get_date = date.today().strftime("%d-%m-%Y")
    get_time = time.strftime("%H:%M:%S", time.localtime())
    print("Date: " + get_date + "\nTime: " + get_time)
    print("Creating Database...")
    #Initialize Database
    if(os.path.exists('database/database.sqlite') == False):
        db = sqlite3.connect('database/database.sqlite')
        #Create tables
        ct = db.cursor()
        #Member Table
        ct.execute("""CREATE TABLE member (
                    id                  INTEGER PRIMARY KEY,
                    membership_id       TEXT NOT NULL,
                    first_name          TEXT NOT NULL,
                    last_name           TEXT NOT NULL,
                    registration_date   TEXT NOT NULL,            
                    email               TEXT NOT NULL,
                    mobile_phone        TEXT NOT NULL,
                    street_name         TEXT NOT NULL,
                    house_number        TEXT NOT NULL,
                    zip_code            TEXT NOT NULL,
                    city                TEXT NOT NULL
        )""")   

        #User Table
        ct.execute("""CREATE TABLE employee (
                    id                  INTEGER PRIMARY KEY,
                    first_name          TEXT NOT NULL,
                    last_name           TEXT NOT NULL,
                    registration_date   TEXT NOT NULL,            
                    username            TEXT NOT NULL,
                    password            TEXT NOT NULL,
                    role                TEXT NOT NULL,
                    tmp_password        TEXT NOT NULL,
                    UNIQUE(username)
        )""")


        #Access Control Table
        ct.execute("""CREATE TABLE access_control (
                    id                  INTEGER PRIMARY KEY,
                    function            TEXT,
                    role                TEXT,
                    access              TEXT
        )""")

        db.commit()

        
        #Creating superadmin
        ct.execute("INSERT INTO employee VALUES (:id, :first_name, :last_name, :registration_date, :username, :password, :role, :tmp_password)", 
            {
                'id':                  None,
                'first_name':          encrypt('Super'),
                'last_name':           encrypt('Administrator'), 
                'registration_date':   get_date, 
                'username':            encrypt('superadmin'),
                'password':            encrypt('Admin321!'), 
                'role':                encrypt('superadmin'),
                'tmp_password':        encrypt('NO')
            }
        )
        db.commit()   

        #Setup Access List
        access_list = [
            {'id': None, 'function': encrypt('1'), 'role': encrypt('advisor'), 'access': encrypt('True')},
            {'id': None, 'function': encrypt('2'), 'role': encrypt('advisor'), 'access': encrypt('True')},
            {'id': None, 'function': encrypt('3'), 'role': encrypt('advisor'), 'access': encrypt('True')},
            {'id': None, 'function': encrypt('4'), 'role': encrypt('advisor'), 'access': encrypt('True')},
            {'id': None, 'function': encrypt('5'), 'role': encrypt('advisor'), 'access': encrypt('False')},
            {'id': None, 'function': encrypt('6'), 'role': encrypt('advisor'), 'access': encrypt('False')},
            {'id': None, 'function': encrypt('7'), 'role': encrypt('advisor'), 'access': encrypt('False')},
            {'id': None, 'function': encrypt('8'), 'role': encrypt('advisor'), 'access': encrypt('False')},
            {'id': None, 'function': encrypt('9'), 'role': encrypt('advisor'), 'access': encrypt('False')},
            {'id': None, 'function': encrypt('10'), 'role': encrypt('advisor'), 'access': encrypt('False')},
            {'id': None, 'function': encrypt('11'), 'role': encrypt('advisor'), 'access': encrypt('False')},
            {'id': None, 'function': encrypt('12'), 'role': encrypt('advisor'), 'access': encrypt('False')},
            {'id': None, 'function': encrypt('13'), 'role': encrypt('advisor'), 'access': encrypt('False')},
            {'id': None, 'function': encrypt('14'), 'role': encrypt('advisor'), 'access': encrypt('False')},
            {'id': None, 'function': encrypt('15'), 'role': encrypt('advisor'), 'access': encrypt('False')},
            {'id': None, 'function': encrypt('16'), 'role': encrypt('advisor'), 'access': encrypt('False')},
            {'id': None, 'function': encrypt('17'), 'role': encrypt('advisor'), 'access': encrypt('False')},

            {'id': None, 'function': encrypt('1'), 'role': encrypt('sysadmin'), 'access': encrypt('True')},
            {'id': None, 'function': encrypt('2'), 'role': encrypt('sysadmin'), 'access': encrypt('True')},
            {'id': None, 'function': encrypt('3'), 'role': encrypt('sysadmin'), 'access': encrypt('True')},
            {'id': None, 'function': encrypt('4'), 'role': encrypt('sysadmin'), 'access': encrypt('True')},
            {'id': None, 'function': encrypt('5'), 'role': encrypt('sysadmin'), 'access': encrypt('True')},
            {'id': None, 'function': encrypt('6'), 'role': encrypt('sysadmin'), 'access': encrypt('True')},
            {'id': None, 'function': encrypt('7'), 'role': encrypt('sysadmin'), 'access': encrypt('True')},
            {'id': None, 'function': encrypt('8'), 'role': encrypt('sysadmin'), 'access': encrypt('True')},
            {'id': None, 'function': encrypt('9'), 'role': encrypt('sysadmin'), 'access': encrypt('True')},
            {'id': None, 'function': encrypt('10'), 'role': encrypt('sysadmin'), 'access': encrypt('True')},
            {'id': None, 'function': encrypt('11'), 'role': encrypt('sysadmin'), 'access': encrypt('True')},
            {'id': None, 'function': encrypt('12'), 'role': encrypt('sysadmin'), 'access': encrypt('True')},
            {'id': None, 'function': encrypt('13'), 'role': encrypt('sysadmin'), 'access': encrypt('True')},
            {'id': None, 'function': encrypt('14'), 'role': encrypt('sysadmin'), 'access': encrypt('False')},
            {'id': None, 'function': encrypt('15'), 'role': encrypt('sysadmin'), 'access': encrypt('False')},
            {'id': None, 'function': encrypt('16'), 'role': encrypt('sysadmin'), 'access': encrypt('False')},
            {'id': None, 'function': encrypt('17'), 'role': encrypt('sysadmin'), 'access': encrypt('False')},

            {'id': None, 'function': encrypt('1'), 'role': encrypt('superadmin'), 'access': encrypt('False')},
            {'id': None, 'function': encrypt('2'), 'role': encrypt('superadmin'), 'access': encrypt('True')},
            {'id': None, 'function': encrypt('3'), 'role': encrypt('superadmin'), 'access': encrypt('True')},
            {'id': None, 'function': encrypt('4'), 'role': encrypt('superadmin'), 'access': encrypt('True')},
            {'id': None, 'function': encrypt('5'), 'role': encrypt('superadmin'), 'access': encrypt('True')},
            {'id': None, 'function': encrypt('6'), 'role': encrypt('superadmin'), 'access': encrypt('True')},
            {'id': None, 'function': encrypt('7'), 'role': encrypt('superadmin'), 'access': encrypt('True')},
            {'id': None, 'function': encrypt('8'), 'role': encrypt('superadmin'), 'access': encrypt('True')},
            {'id': None, 'function': encrypt('9'), 'role': encrypt('superadmin'), 'access': encrypt('True')},
            {'id': None, 'function': encrypt('10'), 'role': encrypt('superadmin'), 'access': encrypt('True')},
            {'id': None, 'function': encrypt('11'), 'role': encrypt('superadmin'), 'access': encrypt('True')},
            {'id': None, 'function': encrypt('12'), 'role': encrypt('superadmin'), 'access': encrypt('True')},
            {'id': None, 'function': encrypt('13'), 'role': encrypt('superadmin'), 'access': encrypt('True')},
            {'id': None, 'function': encrypt('14'), 'role': encrypt('superadmin'), 'access': encrypt('True')},
            {'id': None, 'function': encrypt('15'), 'role': encrypt('superadmin'), 'access': encrypt('True')},
            {'id': None, 'function': encrypt('16'), 'role': encrypt('superadmin'), 'access': encrypt('True')},
            {'id': None, 'function': encrypt('17'), 'role': encrypt('superadmin'), 'access': encrypt('True')}
            
        ]
        ct.executemany("INSERT INTO access_control VALUES (:id, :function, :role, :access)",access_list)
        db.commit()
        db.close()

    if(os.path.exists('database/log.sqlite') == False):
        dblogs = sqlite3.connect('database/log.sqlite')
        #Log Table
        ctlog = dblogs.cursor()
        ctlog.execute("""CREATE TABLE log (
                    id                  INTEGER PRIMARY KEY,
                    username            TEXT,
                    date                TEXT NOT NULL,
                    time                TEXT NOT NULL,
                    activity            TEXT NOT NULL,
                    additional_info     TEXT,
                    suspicious          TEXT NOT NULL,
                    seen                TEXT NOT NULL
        )""")
        dblogs.commit()

        ctlog.execute("INSERT INTO log VALUES (:id, :username, :date, :time, :activity, :additional_info, :suspicious, :seen)",
            {
                'id':                   None,
                'username':             encrypt('PROGRAM'), 
                'date':                 encrypt(get_date), 
                'time':                 encrypt(get_time), 
                'activity':             encrypt('SETUP'), 
                'additional_info':      encrypt('Setting up program'), 
                'suspicious':           encrypt('NO'), 
                'seen':                 encrypt('NO')
            }
        )
        dblogs.commit()
        dblogs.close()

    print("Setup Done...")
    var = input("Press anything to continue....")
    clear_console()
    time.sleep(2)

initialize()