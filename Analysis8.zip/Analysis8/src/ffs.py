import os.path
from utils.misc.clear_console import clear_console
from main.user.login import login
from main.ui.user_interface import user_interface

def main():
    try:
        if(os.path.exists('database/database.sqlite') == True and os.path.exists('database/log.sqlite' == True)):
            user_interface(login())
        else:
            input("Something went wrong. Please contact the administrator.\nPress enter to exit.")
    except KeyboardInterrupt:
        clear_console()
        print("Interrupted")

main()