import glob
import zipfile
import os
import time
from utils.misc.clear_console import clear_console
from utils.insert.insert_log import insert_log
from main.backup.backup_create import backup_create

def backup_restore(user):
    backups = glob.glob("database_backups/*.zip")
    thisScreen = True
    while(thisScreen):
        print("*Note: Before restore an old backup. The program will first create a backup of the current database in case of failure.\nThe program will close after the old backup has been restored.\n\n")
        print("Fill in the number of the backup you want to restore and press enter.")
        for i in range(len(backups)):
            tmp = backups[i][17:]
            print(f"{i+1}: {tmp}")
        print("Quit: Quit to menu")
        user_input = str(input("Input>>")).lower()

        #Checking for input.
        if(user_input == "quit"):
            thisScreen = False
            clear_console()
        else:
            clear_console()
            print("Invalid input. Please try again.\n")

        for j in range(len(backups)):
            if(user_input == str(j+1)):
                try:
                    #Creating backup of current db
                    clear_console()
                    backup_create(user)
                    #Restoring backup db
                    try:
                        with zipfile.ZipFile(backups[j], 'r') as zip_ref:
                            zip_ref.extractall("./")
                        print("\nRestoring backup....")
                        thisScreen = False
                        time.sleep(5)
                        print("Backup restored...")
                        insert_log((f"{user[3]}","RESTORE BACKUP",f"Restored following backup: {backups[j][17:]}","NO"))
                        input("Press enter to close the program.")
                        quit()
                    except:
                        print("Restore failed")
                except:
                    print("Restore impossible...")