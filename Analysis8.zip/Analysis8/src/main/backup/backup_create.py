import time
from zipfile import ZipFile
from datetime import date
from utils.misc.clear_console import clear_console
from utils.insert.insert_log import insert_log

def backup_create(user):
    try:
        print("Starting backup creation....\nGetting date and time....\nGetting database file....\nGetting destination folder....")
        get_date = date.today()
        get_time = time.strftime("%H-%M-%S", time.localtime())
        destination = f"database_backups/{get_date}_{get_time}.zip"
        print("Creating backup....")
        with ZipFile(destination, 'w') as zipObj:
            zipObj.write('database/database.sqlite')
            zipObj.write('database/log.sqlite')
        input("Backup has been created.\n Press enter to continue...")
        insert_log((f"{user[3]}","CREATE BACKUP",f"New backup created.","NO"))
        clear_console()
    except:
        print("An Error has occurred.")
        input("Press enter to continue...")
        clear_console()

