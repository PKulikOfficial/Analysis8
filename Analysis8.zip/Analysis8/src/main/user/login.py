import sqlite3
import sys
import time
from utils.misc.clear_console import clear_console
from utils.encryption.encrypt import encrypt
from utils.encryption.decrypt import decrypt
from utils.encryption.decrypt import decryptTupleSpecificItems
from utils.field_setters.set_password import set_password
from utils.field_setters.set_password import check_password_login
from utils.field_setters.set_username import check_username_login
from utils.update.update_employee_password import update_employee_password
from utils.insert.insert_log import insert_log
from utils.misc.check_suspicious_input import check_suspisious_input

def login():
    try:
        db = sqlite3.connect('database/database.sqlite')
        db_login = db.cursor()

        user = None
        count_faulty_login = 0
        while(user == None):
            print("Welcome to the login screen.")
            print("Please give your username and press enter.")
            username = str(input("Username: ")).lower()
            print("\nPlease give your password and press enter.")
            password = str(input("Password: "))

            #Checking for suspicious input
            check_suspisious_input([username,password], f"{encrypt('LOGGING_ATTEMPT')}")

            #Checks if username and password are valid
            check_username = check_username_login(username)
            check_password = check_password_login(password)

            if(check_username == False or check_password == False):
                count_faulty_login = invalid_credentials(count_faulty_login, username, password)
            else:
                #Selecting first name, last name and role of the employee.
                db_login.execute("SELECT first_name, last_name, role, username, password, tmp_password FROM employee WHERE username=:username AND password=:password", {'username': encrypt(username), 'password': encrypt(password)})
                user = db_login.fetchone()

                #Checking of username and password match a row.
                if(user == None):
                    count_faulty_login = no_user_found(count_faulty_login, username)

                #New password if the tmp_password field was set to yes.
                if(user != None and user[5] == encrypt("YES")):
                    new_password(user)

        db.close()
        clear_console()
        #Succesful login
        return decryptTupleSpecificItems(user[:5], [0,1])
    except:
        print("Something went wrong...")

#Use: one/both credentials are invalid
#Gives user message about unsuccesful login attempt and logs the attempt.
#3 attempts and more equal a 3 minute time-out per attempt.
def invalid_credentials(count_faulty_login,username,password):
    clear_console()
    print("Username and Password do not match. Please try again.\n")
    count_faulty_login = count_faulty_login + 1
    insert_log((f"{encrypt('LOGGING_ATTEMPT')}","UNSUCCESFUL LOGIN",f"Invalid username/password. Attempted login with following username: {username}","NO"))

    if(count_faulty_login >= 3):
        #Let the user wait 3 mins before next login attempt after multiple faulty logins.
        insert_log((f"{encrypt('LOGGING_ATTEMPT')}","UNSUCCESFUL LOGIN",f"Multiple wrong login attempts with invalid credential rules. Last used username: {username}","YES"))
        for i in range(180,0,-1):
            clear_console()                    
            print("Multiple wrong logins attempts.")
            print(f"Time before next attempt:{i}")
            time.sleep(1)
        clear_console()

    return count_faulty_login

#Use: both credentials are valid, but don't exist as an account in db.
#Gives user message about unsuccesful login attempt and logs the attempt.
#3 attempts and more equal a 3 minute time-out per attempt.
def no_user_found(count_faulty_login, username):
    clear_console()
    print("Username and Password do not match. Please try again.\n")
    count_faulty_login = count_faulty_login + 1
    insert_log((f"{encrypt('LOGGING_ATTEMPT')}","UNSUCCESFUL LOGIN",f"Attempted login with following username with a wrong password: {username}","NO"))

    if(count_faulty_login >= 3):
        #Let the user wait 3 mins before next login attempt after multiple faulty logins.
        insert_log((f"{encrypt('LOGGING_ATTEMPT')}","UNSUCCESFUL LOGIN",f"Multiple wrong login attempts. Last used username: {username}","YES"))
        for i in range(180,0,-1):
            clear_console()                    
            print("Multiple wrong logins attempts.")
            print(f"Time before next attempt:{i}")
            time.sleep(1)
        clear_console()

    return count_faulty_login

#Sets a new password for the user if the current pasword was temporary.
def new_password(user):
    clear_console()
    new_pass = set_password(True, decrypt(user[4]))
    clear_console()

    update_employee_password([user[3], new_pass, encrypt("NO")], user[3])

    user = None
    print("Congratulations. You have changed your password.")
    close = str(input("Press enter to continue..."))
    clear_console()