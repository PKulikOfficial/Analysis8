import sqlite3
from utils.misc.clear_console import clear_console
from utils.field_setters.set_password import set_password
from utils.update.update_employee_password import update_employee_password
from utils.encryption.encrypt import encrypt
from utils.encryption.decrypt import decrypt

def reset_password(user):
    thisScreen = True
    error = False
    count_error = 0
    while(thisScreen):
        clear_console()
        if(error):
            print("Wrong input. Please fill in your old password or type \"Quit\" and press enter")

        print("\nReset your password screen.")
        print("Please fill in your old password and press enter. \nType \"Quit\" if you want to quit changeing you password.")    
        old_pass_input = str(input("Input>>"))
        if(old_pass_input.lower() == "quit"):
            thisScreen = False
            clear_console()
        elif(encrypt(old_pass_input) == user[4]):
            thisScreen2 = True
            error2 = False
            error_msg = ""
            while(thisScreen2):
                clear_console()
                if(error2):
                    print(error_msg)
                new_pass = set_password(False, decrypt(user[4]))
                #changing password
                clear_console()
                update_employee_password([user[3], new_pass, encrypt("NO")], user[3])
                print("Congratulations. You have changed your password.\nThe program will now close.")
                input("Press enter to close the program...")
                quit()
        #Logger counter for invalid old password inputs.          
        else:
            count_error = count_error + 1
            error = True
            if(count_error >= 3):
                insert_log((f"{user[3]}","PASSWORD RESET",f"Multiple wrong tries of inputing old password.","YES"))