from utils.misc.clear_console import clear_console
from utils.get.get_member_all import get_member_all

from main.member.member_delete import member_delete
from main.member.member_add import member_add
from main.member.member_modify import member_modify
from main.member.member_search import member_search

def member(func_name, user):
    #Getting members
    members = get_member_all(user[3])

    #Screen Setup
    error = False
    thisScreen = True
    from2 = False
    while(thisScreen):
        #Printing Table name and the members.
        if(error == True):
            print("Invalid input. Please try again.\n")
        print("Members")
        print("{:<10} {:<20} {:<20} {:<20} {:<20} {:<30} {:<30} {:<20} {:<20} {:<20} {:<20}".format('Nr','MemberID','First Name','Last Name','Registration Date','Email','M.Phone','Street','House Nr.','Zip-Code','City'))
        print("------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------")
        for i in range(len(members)):
            print("{:<10} {:<20} {:<20} {:<20} {:<20} {:<30} {:<30} {:<20} {:<20} {:<20} {:<20}".format((i+1),members[i][1],members[i][2],members[i][3],members[i][4],members[i][5],members[i][6],members[i][7],members[i][8],members[i][9],members[i][10]))       

        #func_name specific print    
        if(func_name == 'delete'):
            print("\n\nEnter the number of the member that you want to delete and press enter.")
        elif(func_name == 'modify'):
            print("\n\nEnter the number of the member that you want to modify and press enter.")
        elif(func_name == 'search'):       
            print("\n\nEnter 'Search' and press enter to enter the search screen.")
            print("Enter 'Reset' and press enter to go back to all members.")
        elif(func_name == 'add'):
            print("\n\nEnter 'Add' and press enter to add a new account.")
        print("Enter 'Quit' and press enter if you want to go back to menu.")

        #Checking input.
        user_input = str(input("Input>>")).lower()

        #Checking if func_name is add and if user input is add to prevent faulty input in other screens.
        if(func_name == 'add'):
            if(user_input == 'add'):
                clear_console()
                member_add(user)
                #Getting refreshed member list in case the modification happened.
                members = get_member_all(user[3])
                from2 = True

        if(func_name == 'search'):
            if(user_input == 'search'):                 
                members = member_search(user)
                from2 = True
            elif(user_input == 'reset'):
                members = get_member_all(user[3])
                from2 = True

        #Checking if func_name is not add or search to prevent faulty input in "add" and "search" screen.
        if(func_name != 'add' and func_name != 'search'):
            for i in range(len(members)):
                #Checking if digit input matches a record.
                if(user_input == str(i+1)):
                    clear_console()

                    #Checking which func needs to be processed
                    if(func_name == 'delete'):
                        member_delete(members[i], user)
                        #Getting refreshed member list in case the deletion happened.
                        members = get_member_all(user[3])

                    elif(func_name == 'modify'):
                        member_modify(members[i], user)
                        #Getting refreshed member list in case the modification happened.
                        members = get_member_all(user[3])                       
                    from2 = True
        if(user_input == 'quit'):
            thisScreen = False
            clear_console()
        elif(from2 == True):
            clear_console()
            from2 = False
            error = False
        else:
            error = True
            clear_console()