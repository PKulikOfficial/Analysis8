from utils.field_setters.set_first_name import set_first_name
from utils.field_setters.set_last_name import set_last_name
from utils.field_setters.set_street_name import set_street_name
from utils.field_setters.set_house_number import set_house_number
from utils.field_setters.set_zip_code import set_zip_code
from utils.field_setters.set_city import set_city
from utils.field_setters.set_email import set_email
from utils.field_setters.set_mobile_phone import set_mobile_phone
from utils.field_setters.set_membership_id import set_membership_id

from utils.update.update_member import update_member
from utils.insert.insert_log import insert_log
from utils.misc.clear_console import clear_console

def member_modify(member, user):
    first = member[2]
    last = member[3]
    street = member[7]
    house_nr = member[8]
    zip_code = member[9]
    city = member[10]
    email = member[5]
    mobile_phone = member[6]
    mem_id = member[1]
    reg_date = member[4]

    thisScreen = True
    error = False
    error_msg = ""
    while(thisScreen):
        clear_console()
        if(error):
            print("Invalid input. Please try again.\n")

        print(f"Type the designated number of the field you want to change and press enter.\n1.First Name: {first}\n2.Last Name: {last}\n3.Street Name: {street}\n4.House Number: {house_nr}")
        print(f"5.Zip Code: {zip_code}\n6.City: {city}\n7.Email: {email}\n8.Mobile Phone: {mobile_phone}\nGenerated Membership ID: {mem_id}\nRegistration Date: {reg_date}\n")
        print("Type 'Modify' and press enter to modify the member.")
        print("Type 'Quit' and press enter to cancel the addition")

        user_input = str(input("Input>>"))
        if(user_input == "1"):
            first = set_first_name()
            error = False
        elif(user_input == "2"):
            last = set_last_name()
            error = False
        elif(user_input == "3"):
            street = set_street_name()
            error = False
        elif(user_input == "4"):
            house_nr = set_house_number()
            error = False
        elif(user_input == "5"):
            zip_code = set_zip_code()
            error = False
        elif(user_input == "6"):
            city = set_city()
            error = False
        elif(user_input == "7"):
            email = set_email()
            error = False
        elif(user_input == "8"):
            mobile_phone = set_mobile_phone()
            error = False
        elif(user_input.lower() == "modify"):
            update_member((member[0],first,last,street,house_nr,zip_code,city,email,mobile_phone,mem_id),user[3])
            thisScreen = False
        elif(user_input.lower() == "quit"):
            thisScreen = False
        else:
            error = True



