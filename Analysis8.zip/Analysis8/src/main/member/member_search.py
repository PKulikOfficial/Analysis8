from utils.get.get_member_specific import get_member_specific
from utils.insert.insert_log import insert_log

def member_search(user):
    print("\nPlease input the term you want to search on and press enter.\nThe program will search through all the fields and match (partly) the term.")
    user_input = str(input("Input>>")).lower()
    filtered_members = get_member_specific(user_input, user[3])
    insert_log((f"{user[3]}","SEARCH MEMBER",f"Searched member table with following term: {user_input}","NO"))
    return filtered_members