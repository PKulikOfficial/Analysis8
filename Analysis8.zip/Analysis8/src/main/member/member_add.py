from utils.field_setters.set_first_name import set_first_name
from utils.field_setters.set_last_name import set_last_name
from utils.field_setters.set_street_name import set_street_name
from utils.field_setters.set_house_number import set_house_number
from utils.field_setters.set_zip_code import set_zip_code
from utils.field_setters.set_city import set_city
from utils.field_setters.set_email import set_email
from utils.field_setters.set_mobile_phone import set_mobile_phone
from utils.field_setters.set_membership_id import set_membership_id

from utils.insert.insert_member import insert_member
from utils.misc.clear_console import clear_console

def member_add(user):
    first = set_first_name()
    last = set_last_name()
    street = set_street_name()
    house_nr = set_house_number()
    zip_code = set_zip_code()
    city = set_city()
    email = set_email()
    mobile_phone = set_mobile_phone()
    mem_id = set_membership_id(user)

    thisScreen = True
    error = False
    error_msg = ""
    while(thisScreen):
        clear_console()
        if(error):
            print("Invalid input. Please try again.\n")

        print(f"Type the designated number and press enter if you want to change something.\n1.First Name: {first}\n2.Last Name: {last}\n3.Street Name: {street}\n4.House Number: {house_nr}")
        print(f"5.Zip Code: {zip_code}\n6.City: {city}\n7.Email: {email}\n8.Mobile Phone: {mobile_phone}\nGenerated Membership ID: {mem_id}\n")
        print("Type 'Add' and press enter to add the new member.")
        print("Type 'Quit' and press enter to cancel the addition")

        user_input = str(input("Input>>"))
        if(user_input == "1"):
            first = set_first_name()
            error = False
        elif(user_input == "2"):
            last = set_last_name()
            error = False
        elif(user_input == "3"):
            street = set_street_name()
            error = False
        elif(user_input == "4"):
            house_nr = set_house_number()
            error = False
        elif(user_input == "5"):
            zip_code = set_zip_code()
            error = False
        elif(user_input == "6"):
            city = set_city()
            error = False
        elif(user_input == "7"):
            email = set_email()
            error = False
        elif(user_input == "8"):
            mobile_phone = set_mobile_phone()
            error = False
        elif(user_input.lower() == "add"):
            insert_member((first,last,street,house_nr,zip_code,city,email,mobile_phone,mem_id), user[3])
            thisScreen = False
        elif(user_input.lower() == "quit"):
            thisScreen = False
        else:
            error = True



