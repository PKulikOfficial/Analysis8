from utils.misc.clear_console import clear_console
from utils.delete.delete_member import delete_member

def member_delete(member, user):
    #Screen setup
    error = False
    thisScreen = True
    while(thisScreen):
        #Error and asking user if he selected the correct member.
        if(error == True):
            print("Invalid input.Please try again.\n")
        print("Are you sure you want to delete this account?")
        print(f"MemberID: {member[1]}\nFirst Name: {member[2]}\nLast Name: {member[3]}\nRegistration Date: {member[4]}\nEmail: {member[5]}\nM.Phone: {member[6]}\nStreet: {member[7]}\nHouse Nr.: {member[8]}\nZip-Code: {member[9]}\nCity: {member[10]}\n")

        #Handling input
        #Yes -> Deleting member
        #No -> Going back to member screen
        #Else -> Invalid input error.
        print("Input one of the following and press enter:\nYes: Delete member\nNo: Go back to members table")
        user_input = str(input("Input>>")).lower()
        if(user_input == "yes"):
            delete_member(member[0], member[1], user[3])
            thisScreen = False
            clear_console()
        elif(user_input == "no"):
            thisScreen = False
            clear_console()
        else:
            error = True
            clear_console()