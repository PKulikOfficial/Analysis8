from utils.misc.clear_console import clear_console
from utils.get.get_employees_specific import get_employees_specific

#Function Files
from main.employee.employee_delete import employee_delete
from main.employee.employee_reset_password import employee_reset_password
from main.employee.employee_modify import employee_modify
from main.employee.employee_add import employee_add

#Gets all employees of specific role and let's you perform the functions you want to perform
#Current Functions:
# 'add'
# 'delete'
# 'modify'
# 'reset_pass'
def employee(role, func_name, user):
    #Getting employees with correct role
    employees = get_employees_specific(role, user[3])

    #Screen Setup
    error = False
    thisScreen = True
    from2 = False
    while(thisScreen):
        #Printing Table name and the employees with correct role.
        if(error == True):
            print("Invalid input. Please try again.\n")
        if(role == 'advisor'):
            print("Advisor Table")
        if(role == 'sysadmin'):
            print("System Administrator Table")
        print("{:<10} {:<20} {:<20} {:<20} {:<20} {:<20}".format('Nr','First Name','Last Name','Username','Role','Registration Date'))
        print("------------------------------------------------------------------------------------------------------------------------------------------")
        for i in range(len(employees)):
            print("{:<10} {:<20} {:<20} {:<20} {:<20} {:<20}".format((i+1),employees[i][1],employees[i][2],employees[i][4],employees[i][5],employees[i][3]))

        #func_name specific print    
        if(func_name == 'delete'):
            print("\n\nEnter the number of the account that you want to delete and press enter.")
        elif(func_name == 'modify'):
            print("\n\nEnter the number of the account that you want to modify and press enter.")
        elif(func_name == 'reset_pass'):       
            print("\n\nEnter the number of the account that needs a password reset and press enter.")
        elif(func_name == 'add'):
            print("\n\nEnter 'Add' and press enter to add a new account.")
        print("Enter 'Quit' and press enter if you want to go back to menu.")

        #Checking input.
        user_input = str(input("Input>>")).lower()

        #Checking if func_name is add and if user input is add to prevent faulty input in other screens.
        if(func_name == 'add'):
            if(user_input == 'add'):
                clear_console()
                employee_add(role, user)
                #Getting refreshed employee list in case the modification happened.
                employees = get_employees_specific(role, user[3])
                from2 = True

        #Checking if func_name is not add to prevent faulty input in "add" screen.
        if(func_name != 'add'):
            for i in range(len(employees)):
                #Checking if digit input matches a record.
                if(user_input == str(i+1)):
                    clear_console()

                    #Checking which func needs to be processed
                    if(func_name == 'delete'):
                        employee_delete(employees[i], user)
                        #Getting refreshed employee list in case the deletion happened.
                        employees = get_employees_specific(role, user[3])

                    elif(func_name == 'modify'):
                        employee_modify(employees[i], user)
                        #Getting refreshed employee list in case the modification happened.
                        employees = get_employees_specific(role, user[3])

                    elif(func_name == 'reset_pass'):                      
                        employee_reset_password(employees[i], user)
                        
                    from2 = True
        if(user_input == 'quit'):
            thisScreen = False
            clear_console()
        elif(from2 == True):
            clear_console()
            from2 = False
        else:
            error = True
            clear_console()