from utils.field_setters.set_first_name import set_first_name
from utils.field_setters.set_last_name import set_last_name
from utils.field_setters.set_username import set_username
from utils.field_setters.set_password import set_password

from utils.insert.insert_employee import insert_employee
from utils.misc.clear_console import clear_console

def employee_add(role, user):
    first = set_first_name()
    last = set_last_name()
    username = set_username(user).lower()
    password = set_password()

    thisScreen = True
    error = False
    error_msg = ""
    while(thisScreen):
        clear_console()
        if(error):
            print("Invalid input. Please try again.\n")

        print(f"Type the designated number and press enter if you want to change something.\n1.First Name: {first}\n2.Last Name: {last}\n3.Username: {username}\n4.Password: #HIDDEN#\n")
        print("Type 'Add' to add the new account.")
        print("Type 'Quit' to cancel the addition")

        user_input = str(input("Input>>"))
        if(user_input == "1"):
            first = set_first_name()
            error = False
        elif(user_input == "2"):
            last = set_last_name()
            error = False
        elif(user_input == "3"):
            username = set_username().lower()
            error = False
        elif(user_input == "4"):
            password = set_password()
            error = False
        elif(user_input.lower() == "add"):
            insert_employee([first,last,username,password,role], user[3])
            thisScreen = False
        elif(user_input.lower() == "quit"):
            thisScreen = False
        else:
            error = True



