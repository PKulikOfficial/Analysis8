from utils.field_setters.set_first_name import set_first_name
from utils.field_setters.set_last_name import set_last_name
from utils.field_setters.set_username import set_username
from utils.field_setters.set_password import set_password
from utils.field_setters.set_role import set_role
 
from utils.update.update_employee import update_employee
from utils.misc.clear_console import clear_console
from utils.encryption.decrypt import decrypt

def employee_modify(employee, user):
    e_id = employee[0]
    first = employee[1]
    last = employee[2]
    reg_date = employee[3]
    username = employee[4]
    role = employee[5]

    thisScreen = True
    error = False
    error_msg = ""
    while(thisScreen):
        clear_console()
        if(error):
            print("Invalid input. Please try again.\n")

        print(f"Type the designated number of the field you want to change.\n1.First Name: {first}\n2.Last Name: {last}\n3.Username: {username}")
        if(decrypt(user[2]) == "superadmin"):
            print(f"4.Role: {role}")
        else:
            print(f"Role: {role}")
        print(f"Registration Date: {reg_date}\n")
        print("Type 'Modify' and press enter to update the employee.")
        print("Type 'Quit' and press enter to cancel the addition\n")

        user_input = str(input("Input>>"))

        if(user_input == "1"):
            first = set_first_name()
            error = False
        elif(user_input == "2"):
            last = set_last_name()
            error = False
        elif(user_input == "3"):
            username = set_username().lower()
            error = False
        elif(decrypt(user[2]) == "superadmin" and user_input == "4"):
            role = set_role()
            error = False
        elif(user_input.lower() == "modify"):
            update_employee([e_id,first,last,username,role], user[3])
            thisScreen = False
        elif(user_input.lower() == "quit"):
            thisScreen = False
        else:
            error = True



