from utils.misc.clear_console import clear_console
from utils.update.update_employee_password import update_employee_password
from utils.field_setters.set_password import set_password
from utils.encryption.encrypt import encrypt

def employee_reset_password(employee, user):
    #Screen setup
    error = False
    thisScreen = True
    while(thisScreen):
        #Error and asking user if he selected the correct account.
        if(error == True):
            print("Invalid input.Please try again.\n")
        print("Are you sure you want to reset the password of this account?")
        print(f"First Name: {employee[1]}\nLast Name: {employee[2]}\nRegistration Date: {employee[3]}\nUsername: {employee[4]}\nRole: {employee[5]}\n")

        #Handling input
        #Yes -> Resetting password
        #No -> Going back to account screen
        #Else -> Invalid input error.
        print("Input one of the following and press enter:\nYes: Reset password\nNo: Go back to accounts")
        user_input = str(input("Input>>")).lower()
        if(user_input == "yes"):
            new_pass = set_password()
            clear_console()
            update_employee_password([encrypt(employee[4]), new_pass, encrypt("YES")], user[3])
            clear_console()
            thisScreen = False
        elif(user_input == "no"):
            thisScreen = False
            clear_console()
        else:
            error = True
            clear_console()