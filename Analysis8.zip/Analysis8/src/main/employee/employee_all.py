from utils.misc.clear_console import clear_console
from utils.get.get_employees_all import get_employees_all

def employee_all(user):
    try:
        employees = get_employees_all(user[3])
        print("Users Table")
        print("{:<10} {:<20} {:<20} {:<20} {:<20} {:<20}".format('ID','First Name','Last Name','Username','Role','Registration Date'))
        print("------------------------------------------------------------------------------------------------------------------------------------------")
        for i in range(len(employees)):
            print("{:<10} {:<20} {:<20} {:<20} {:<20} {:<20}".format(employees[i][0],employees[i][1],employees[i][2],employees[i][4],employees[i][5],employees[i][3]))
        input("Press enter to go back to menu...")
        clear_console()
    except:
        input("Failed to load the employees. Press enter to continue...")