from utils.misc.clear_console import clear_console
from utils.delete.delete_employee import delete_employee

def employee_delete(employee, user):
    #Screen setup
    error = False
    thisScreen = True
    while(thisScreen):
        #Error and asking user if he selected the correct account.
        if(error == True):
            print("Invalid input.Please try again.\n")
        print("Are you sure you want to delete this account?")
        print(f"First Name: {employee[1]}\nLast Name: {employee[2]}\nRegistration Date: {employee[3]}\nUsername: {employee[4]}\nRole: {employee[5]}\n")

        #Handling input
        #Yes -> Deleting user
        #No -> Going back to account screen
        #Else -> Invalid input error.
        print("Input one of the following and press enter:\nYes: Delete account\nNo: Go back to accounts")
        user_input = str(input("Input>>")).lower()
        if(user_input == "yes"):
            delete_employee(employee[0],employee[4],user[3])
            thisScreen = False
            clear_console()
        elif(user_input == "no"):
            thisScreen = False
            clear_console()
        else:
            error = True
            clear_console()