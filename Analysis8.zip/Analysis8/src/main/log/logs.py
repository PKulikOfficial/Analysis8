from utils.get.get_logs import get_logs
from utils.update.update_logs_to_seen import update_logs_to_seen
from utils.misc.clear_console import clear_console

def logs():
    try:
        logs = get_logs()
        print("Logs Table")
        print("{:<8} {:<15} {:<10} {:<10} {:<10} {:<10} {:<30} {:<30}".format('ID','Username','Date','Time','Suspicious','Seen','Activity','Additional Information'))
        print("------------------------------------------------------------------------------------------------------------------------------------------")
        for i in range(len(logs)):
            print("{:<8} {:<15} {:<10} {:<10} {:<10} {:<10} {:<30} {:<30}".format(logs[i][0],logs[i][1],logs[i][2],logs[i][3],logs[i][6],logs[i][7],logs[i][4],logs[i][5],))
        update_logs_to_seen()
        input("Press enter to go back to menu...")
        clear_console()
    except:
        input("Something went wrong. Press enter to go back to menu...")

