#Member Function Screens
from main.member.member import member

#User Function Screens
from main.user.reset_password import reset_password

#Employee Function Screens
from main.employee.employee import employee
from main.employee.employee_all import employee_all

#Backup Function Screens
from main.backup.backup_create import backup_create
from main.backup.backup_restore import backup_restore

#Logs Function Screens
from main.log.logs import logs

#Util Functions
from utils.misc.clear_console import clear_console
from utils.get.get_menu_value import get_menu_value
from main.ui.user_interface_print import user_interface_print


#Makes it dynamically possible to select an option according to access.
def user_interface_logic(options, user):
    menu_values = get_menu_value(options)
    thisScreen = True
    error = False
    while(thisScreen):        
        user_interface_print(options, user[2], error)
        user_input = str(input("Input>>")).lower()

        #Reset Password
        if(options[0][1] == "True" and user_input == str(menu_values[0])):
            error = False
            clear_console()
            reset_password(user)
        #Add new member
        elif(options[1][1] == "True" and user_input == str(menu_values[1])):
            error = False
            clear_console()
            member('add', user)
        #Update member
        elif(options[2][1] == "True" and user_input == str(menu_values[2])):
            error = False
            clear_console()
            member('modify', user)
        #Search for member
        elif(options[3][1] == "True" and user_input == str(menu_values[3])):
            error = False
            clear_console()
            member('search', user)
        #Check users
        elif(options[4][1] == "True" and user_input == str(menu_values[4])):
            error = False
            clear_console()
            employee_all(user)
        #Add advisor
        elif(options[5][1] == "True" and user_input == str(menu_values[5])):
            error = False
            clear_console()
            employee('advisor', 'add', user)
        #Update advisor
        elif(options[6][1] == "True" and user_input == str(menu_values[6])):
            error = False
            clear_console()
            employee('advisor', 'modify',user)
        #Delete advisor
        elif(options[7][1] == "True" and user_input == str(menu_values[7])):
            error = False
            clear_console()
            employee('advisor', 'delete',user)
        #Reset advisor password (tmp)
        elif(options[8][1] == "True" and user_input == str(menu_values[8])):
            error = False
            clear_console()
            employee('advisor', 'reset_pass', user)
        #Create backup
        elif(options[9][1] == "True" and user_input == str(menu_values[9])):
            error = False
            clear_console()
            backup_create(user)
        #Restore backup
        elif(options[10][1] == "True" and user_input == str(menu_values[10])):
            error = False
            clear_console()
            backup_restore(user)
        #See logs
        elif(options[11][1] == "True" and user_input == str(menu_values[11])):
            error = False
            clear_console()
            logs()
        #Delete member
        elif(options[12][1] == "True" and user_input == str(menu_values[12])):
            error = False
            clear_console()
            member('delete', user)
        #Add new admin
        elif(options[13][1] == "True" and user_input == str(menu_values[13])):
            error = False
            clear_console()
            employee('sysadmin', 'add', user)
        #Update admin
        elif(options[14][1] == "True" and user_input == str(menu_values[14])):
            error = False
            clear_console()
            employee('sysadmin', 'modify', user)
        #Delete admin
        elif(options[15][1] == "True" and user_input == str(menu_values[15])):
            error = False
            clear_console()
            employee('sysadmin', 'delete', user)
        #Reset admin password
        elif(options[16][1] == "True" and user_input == str(menu_values[16])):
            error = False
            clear_console()
            employee('sysadmin', 'reset_pass', user)
        #Quit
        elif(user_input == "quit"):
            quit()
        #Invalid input
        else:
            clear_console()
            error = True