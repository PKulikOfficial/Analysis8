from utils.get.get_menu_value import get_menu_value
from utils.get.get_logs_suspicious_not_seen import get_logs_suspicious_not_seen
from utils.encryption.decrypt import decrypt

#Prints the menu dynamically according to the giving rights.
def user_interface_print(options, role, error):
    if(error):
            print("Invalid input. Please try again.\n")
    #Message for superadmin and sysadmins about suspicious activity
    if(decrypt(role) == "superadmin" or decrypt(role) == "sysadmin"):
        suspicious_logs = get_logs_suspicious_not_seen()
        print(f"There are {suspicious_logs[0]} logs unread with suspicious activity")

    print("\nPlease type in the designated number/word of the task you want to perform and press enter")
    print("\nMenu")
    print("-------------------------------------------------")

    menu_values = get_menu_value(options)
    #Updating your password.
    if(options[0][1] == "True"):
        print(f"{menu_values[0]}: Update your password.")

    #Add a new member.
    if(options[1][1] == "True"):
        print(f"{menu_values[1]}: Add a new member.")

    #Update member information.
    if(options[2][1] == "True"):
        print(f"{menu_values[2]}: Update Member information.")

    #Search and retrieve member information.
    if(options[3][1] == "True"):
        print(f"{menu_values[3]}: Search and retrieve member information.")

    #Check list of users and their roles.
    if(options[4][1] == "True"):
        print(f"{menu_values[4]}: Check list of users and their roles.")

    #Add a new advisor.
    if(options[5][1] == "True"):
        print(f"{menu_values[5]}: Add a new advisor.")

    #Update existing advisor
    if(options[6][1] == "True"):
        print(f"{menu_values[6]}: Update existing advisor.")

    #Delete an advisor account
    if(options[7][1] == "True"):
        print(f"{menu_values[7]}: Delete an advisor account.")
    
    #Reset advisor password (Temporary Password)
    if(options[8][1] == "True"):
        print(f"{menu_values[8]}: Reset advisor password.")

    #Make a database backup
    if(options[9][1] == "True"):
        print(f"{menu_values[9]}: Make a database backup.")

    #Restore a database backup
    if(options[10][1] == "True"):
        print(f"{menu_values[10]}: Restore a database backup.")

    #See logs
    if(options[11][1] == "True"):
        print(f"{menu_values[11]}: See logs.")
    
    #Delete a member
    if(options[12][1] == "True"):
        print(f"{menu_values[12]}: Delete a member.")
    
    #Add an new administrator
    if(options[13][1] == "True"):
        print(f"{menu_values[13]}: Add an new administrator.")
    
    #Update an existing administrator
    if(options[14][1] == "True"):
        print(f"{menu_values[14]}: Update an existing administrator.")
    
    #Delete an administrator account
    if(options[15][1] == "True"):
        print(f"{menu_values[15]}: Delete an administrator account.")
    
    #Reset password of an administrator
    if(options[16][1] == "True"):
        print(f"{menu_values[16]}: Reset password of an administrator.")
    
    #Quit program
    if(True):
        print(f"Quit: Quit program")
    print("-------------------------------------------------")