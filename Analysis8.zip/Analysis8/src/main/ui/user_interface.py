from utils.get.get_access_control import get_access_control
from main.ui.user_interface_logic import user_interface_logic
from utils.insert.insert_log import insert_log

#User variable:
#user[0]: First Name
#user[1]: Last Name
#'advisor': Role
def user_interface(user):
    try:
        #Passing role to get permissions.
        insert_log((f"{user[3]}","SUCCESFUL LOGIN","User logged in.","NO"))
        access_control = (get_access_control(user[2], user[3]))
        user_interface_logic(access_control, user)
    except SystemExit:
        return
    except:
        print("Failed to open the program.")
        input("Press enter to close the program...")