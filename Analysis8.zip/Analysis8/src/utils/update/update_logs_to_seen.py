import sqlite3
import os.path

from utils.encryption.encrypt import encrypt

#Sets all logs to seen when an admin has checked the logs.
def update_logs_to_seen():
    #Searching for DB file.
    if(os.path.exists('database/log.sqlite') == True):
        try:
            db = sqlite3.connect('database/log.sqlite')
            #Try updating to DB.
            try:    
                logs = db.cursor()
                no = encrypt('NO')
                yes = encrypt('YES')
                logs.execute("UPDATE log SET seen=:yes WHERE seen=:no", {'no': no, 'yes':yes})
                db.commit()
                db.close()
            #Updating to DB failed. Raising error.
            except:
                db.close()
        except:
            return
    #No DB found. Raising error.
    else:
        return