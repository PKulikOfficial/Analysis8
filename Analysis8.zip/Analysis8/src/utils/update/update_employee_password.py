import sqlite3
import os.path

from utils.encryption.encrypt import encrypt
from utils.encryption.decrypt import decrypt
from utils.insert.insert_log import insert_log
from utils.misc.check_suspicious_input import check_suspisious_input

#Needs list of 3 values
#[0] = username
#[1] = new password
#[2] = YES/NO if the pass is temporary (used for resetting for other users)
def update_employee_password(values, user):
    check_suspisious_input(values, user)
    #Searching for DB file.
    if(os.path.exists('database/database.sqlite') == True):
        try:
            db = sqlite3.connect("database/database.sqlite")
            #Try updating to DB.
            try:
                username = values[0]
                password = encrypt(values[1])
                tmp_password = values[2]
                update_emp = db.cursor() 
                update_emp.execute("UPDATE employee SET password=:password, tmp_password=:tmp_password WHERE username=:username", {'password': password, 'tmp_password': tmp_password, 'username': username})
                db.commit()
                db.close()
                insert_log((f"{user}","RESET EMPLOYEE PASSWORD",f"Password reset for employee with following username: {decrypt(username)}.","NO"))
            #Updating to DB failed. Raising error.
            except:
                db.close()
                insert_log((f"{user}","RESET EMPLOYEE PASSWORD",f"Failed to reset password. Table does not exist.","YES"))
                print("\nCritical level error. Please contact the administrator.")
                input("Press enter to continue...")                
        except:
            insert_log((f"{user}","RESET EMPLOYEE PASSWORD",f"Failed to make a connection with the database.","NO"))
            print("\nConnecting to database failed.")
            input("Press enter to continue...")
    #No DB found. Raising error.
    else:
        insert_log((f"{user}","RESET EMPLOYEE PASSWORD",f"Failed to reset password. Database does not exist.","YES"))
        print("\nCritical level error. Please contact the administrator.")
        input("Press enter to continue...")