import sqlite3
import os.path

from utils.encryption.encrypt import encrypt
from utils.insert.insert_log import insert_log
from utils.misc.check_suspicious_input import check_suspisious_input

#[0] -> Id
#[1] -> First name
#[2] -> Last name
#[3] -> Street name
#[4] -> House number
#[5] -> Zip Code
#[6] -> City
#[7] -> Email
#[8] -> Mobile Phone
#[9] -> Membership ID

#Updates member based on id.
def update_member(member,username):
    check_suspisious_input(member, username)
    #Searching for DB file.
    if(os.path.exists('database/database.sqlite') == True):
        try:
            db = sqlite3.connect('database/database.sqlite')
            #Try updating to DB.
            try:
                upd_member = db.cursor()
                upd_member.execute("UPDATE member SET first_name=:first_name, last_name=:last_name, email=:email, mobile_phone=:mobile_phone, street_name=:street_name, house_number=:house_number, zip_code=:zip_code, city=:city WHERE id=:id",
                    {
                        'id':                   member[0],
                        'first_name':           encrypt(member[1]),
                        'last_name':            encrypt(member[2]),
                        'email':                encrypt(member[7]),
                        'mobile_phone':         encrypt(member[8]),  
                        'street_name':          encrypt(member[3]),
                        'house_number':         encrypt(member[4]),
                        'zip_code':             encrypt(member[5]),
                        'city':                 encrypt(member[6]),
                    }
                )
                db.commit()
                db.close()
                insert_log((f"{username}","MODIFY MEMBER",f"Modified member with Membership ID: {member[9]}","NO"))
                print("Member has been modified.\n")
                input("Press enter to continue...")
            #Updating to DB failed. Raising error.
            except:
                db.close()
                insert_log((f"{username}","MODIFY MEMBER",f"Failed modify member. Table does not exist.","YES"))
                print("\nCritical level error. Please contact the administrator.")
                input("Press enter to continue...")                
        except:
            insert_log((f"{username}","MODIFY MEMBER",f"Failed to make a connection with the database.","NO"))
            print("\nConnecting to database failed.")
            input("Press enter to continue...")
    #No DB found. Raising error.
    else:
        insert_log((f"{username}","MODIFY MEMBER",f"Failed to modify member. Database does not exist.","YES"))
        print("\nCritical level error. Please contact the administrator.")
        input("Press enter to continue...")