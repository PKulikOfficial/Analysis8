import sqlite3
import os.path

from utils.encryption.encrypt import encrypt
from utils.encryption.decrypt import decrypt
from utils.insert.insert_log import insert_log
from utils.misc.check_suspicious_input import check_suspisious_input

#Needs list of 3 values
#[0] = id
#[1] = first name
#[2] = last name
#[3] = username
#[4] = role
def update_employee(employee, user):
    check_suspisious_input(employee, user)
    #Searching for DB file.
    if(os.path.exists('database/database.sqlite') == True):
        try:
            db = sqlite3.connect("database/database.sqlite")
            #Try updating to DB.
            try:
                e_id = employee[0]
                first = encrypt(employee[1])
                last = encrypt(employee[2])
                username = encrypt(employee[3])
                role = encrypt(employee[4])
                update_emp = db.cursor()
                update_emp.execute("UPDATE employee SET first_name=:first, last_name=:last, username=:username, role=:role WHERE id=:id", {'id': e_id, 'first': first, 'last': last, 'username': username, 'role': role})
                db.commit()
                db.close()
                insert_log((f"{user}","MODIFY EMPLOYEE",f"Employee modified with following username: {decrypt(username)}.","NO"))
                print("\nEmployee has been updated.")
                input("Press enter to continue...")
        #Updating to DB failed. Raising error.
            except:
                db.close()
                insert_log((f"{user}","MODIFY EMPLOYEE",f"Failed to modify employee. Table does not exist.","YES"))
                print("\nCritical level error. Please contact the administrator.")
                input("Press enter to continue...")                
        except:
            insert_log((f"{user}","MODIFY EMPLOYEE",f"Failed to make a connection with the database.","NO"))
            print("\nConnecting to database failed.")
            input("Press enter to continue...")
    #No DB found. Raising error.
    else:
        insert_log((f"{user}","MODIFY EMPLOYEE",f"Failed to modify employee. Database does not exist.","YES"))
        print("\nCritical level error. Please contact the administrator.")
        input("Press enter to continue...")