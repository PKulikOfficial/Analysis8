import string
from utils.misc.clear_console import clear_console

#Sets Password
def set_password(tmp=False, old_pass=None):
    thisScreen = True
    error = False
    error_msg = ""

    while(thisScreen):
        clear_console()
        if(error):
            print(error_msg)

        if(tmp):
            print("Temporary password reset.\nPlease type in your new password and press enter.")
        else:
            print("Please fill in the Password and press enter.")
        user_input = str(input("Input>>"))
        print("\nPlease confirm the password by typing it in again and press enter.")
        confirm = str(input("Input>>"))

        if(user_input == old_pass):
            error = True
            error_msg = "You need to choose a new password!"
        elif(user_input == confirm):
            result = check_password(user_input)
            error = result[0]
            thisScreen = result[0]
            error_msg = result[1]
        else:
            error = True
            error_msg = "Passwords do not match. Please try again."

    return user_input

#Checks if password contains the following rules:
# -Password field is not empty.
# -Password is at least 8 characters
# -Password is not longer than 30 characters
# -Password contains only the following chars: (a-z)(A-Z)(0-9) and ~!@#$%&_-+=`|\(){}[]:;'<>,.?/
# -Password has at least 1 of each the following: lowercase letter, uppercase letter, digit, special character

#function returns False and no error message if password is right
#function returns True and an error message if a criteria has not been met
#Return format is a Tuple(Bool, Error). "Error" is a string.
def check_password(password):
    #Checking password length
    if(password == ""):
        return (True,"No password given. Please fill in a password.")
    elif(len(password) < 8):
        return (True,"Password must be at least 8 characters long. Please try again.")
    elif(len(password) > 30):
        return (True,"Password is longer than 30 characters. Please try again.")

    #Checking if password contains only valid characters and has at least 1 of each
    allowed_chars = set(string.ascii_lowercase + string.ascii_uppercase + string.digits + "~!@#$%&_-+=`|\()}{[]:;'<>,.?/")
    count_lower = 0
    count_upper = 0
    count_digit = 0
    count_special = 0
    for c in password:
        if(c not in allowed_chars):
            return (True, "Password may contain only the following characters: (a-z)(A-Z)(0-9)(~!@#$%&_-+=`|\()}{[]:;'<>,.?/)")
        #Count each type of char.
        if(c in string.ascii_lowercase):
            count_lower = count_lower + 1
        elif(c in string.ascii_uppercase):
            count_upper = count_upper + 1
        elif(c in string.digits):
            count_digit = count_digit + 1
        elif(c in set("~!@#$%&_-+=`|\()}{[]:;'<>,.?/")):
            count_special = count_special + 1
    #Checking if each char type exists in password
    if(count_digit <= 0 or count_lower <= 0 or count_upper <= 0 or count_special <= 0):
        return (True, "Password must contain at least one lowercase letter, uppercase letter, digit, special character \"(~!@#$%&_-+=`|\()}{[]:;'<>,.?/)\"")
    #Password meets the criteria
    return (False, "")

#Checks if password contains the following rules:
# -Password field is not empty.
# -Password is at least 8 characters
# -Password is not longer than 30 characters
# -Password contains only the following chars: (a-z)(A-Z)(0-9) and ~!@#$%&_-+=`|\(){}[]:;'<>,.?/
# -Password has at least 1 of each the following: lowercase letter, uppercase letter, digit, special character

#function returns True if password is valid password that could be in the db
#function returns False if the password is not valid
def check_password_login(password):
    #Checking password length
    if(password == ""):
        return False
    elif(len(password) < 8):
        return False
    elif(len(password) > 30):
        return False

    #Checking if password contains only valid characters and has at least 1 of each
    allowed_chars = set(string.ascii_lowercase + string.ascii_uppercase + string.digits + "~!@#$%&_-+=`|\()}{[]:;'<>,.?/")
    count_lower = 0
    count_upper = 0
    count_digit = 0
    count_special = 0
    for c in password:
        if(c not in allowed_chars):
            return False
        #Count each type of char.
        if(c in string.ascii_lowercase):
            count_lower = count_lower + 1
        elif(c in string.ascii_uppercase):
            count_upper = count_upper + 1
        elif(c in string.digits):
            count_digit = count_digit + 1
        elif(c in set("~!@#$%&_-+=`|\()}{[]:;'<>,.?/")):
            count_special = count_special + 1
    #Checking if each char type exists in password
    if(count_digit <= 0 or count_lower <= 0 or count_upper <= 0 or count_special <= 0):
        return False
    #Password meets the criteria
    return True