import string
from random import randint
from utils.get.get_member_membership_id import get_member_membership_id

#Sets Membership ID
def set_membership_id(user):
    thisScreen = True
    while(thisScreen):
        array = [0] * 10
        #Assign random int
        # [0] -> 1-9
        # [1]...[8] -> 0-9
        # [9] -> [0]...[8] % 10
        array[0] = randint(1, 9)
        for i in range(len(array)):
            if(i > 0 and i < 9):
                array[i] = randint(0, 9)
        for i in range(len(array)):
            if(i < 9):
                array[9] = array[9] + array[i]
            if(i == 9):
                array[i] = array[i] % 10
        # Turn into string
        result = ""
        for i in range(len(array)):
            result = result + str(array[i])
        
        checked = check_membership_id(result, user)
        if(checked == False):
            thisScreen = False
    return result

def check_membership_id(mem_id, user):
    current_ids = get_member_membership_id(user[3])
    for i in range(len(current_ids)):
        if(current_ids[i][0] == mem_id):
            return True
    return False
        
