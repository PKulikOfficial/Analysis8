import string
from utils.misc.clear_console import clear_console

#Sets Mobile Phone
def set_mobile_phone():
    thisScreen = True
    error = False
    error_msg = ""

    while(thisScreen):
        clear_console()
        if(error):
            print(error_msg)
        print("Please complete the Mobile Phone number and press enter.")
        user_input = str(input("Input>> +31-6-"))

        result = check_mobile_phone(user_input)
        error = result[0]
        thisScreen = result[0]
        error_msg = result[1]

    return f"+31-6-{user_input}"

#Check if Mobile Phone number contains the following rules:
# -Mobile Phone number is not empty
# -Mobile Phone number input is not shorter than 8 digits.
# -Mobile Phone number input is not longer than 8 digits.
# -Mobile Phone number input consists of only digits.

#function returns False and no error message if last name is right
#function returns True and an error message if a criteria has not been met
#Return format is a Tuple(Bool, Error). "Error" is a string.
def check_mobile_phone(mphone):

    if(mphone == ""):
        return ((True,"No Mobile Phone number given. Please try again.\n"))
    #Checking if digits    
    for c in mphone:
        if(c not in string.digits):
            return(True,"Mobile phone number must only consist of digits(No spaces allowed).Please try again\n")
    #Checking name length
    if(len(mphone) > 8):
        return (True,"Mobile Phone number is longer than 8 digits. Please try again.\n")
    elif(len(mphone) < 8):
        return (True,"Mobile Phone number is shorter than 8 digits. Please try again.\n")
    #Mobile Phone number meets the criteria
    return (False, "")