import string
from utils.misc.clear_console import clear_console

#Sets House Number
def set_house_number():
    thisScreen = True
    error = False
    error_msg = ""

    while(thisScreen):
        clear_console()
        if(error):
            print(error_msg)
        print("Please fill in the House Number and press enter.")
        user_input = str(input("Input>>"))

        result = check_house_number(user_input)
        error = result[0]
        thisScreen = result[0]
        error_msg = result[1]

    return user_input

#Check if House Number contains the following rules:
# -House Number is not empty
# -House Number is not longer than 20 chars

#function returns False and no error message if house number is right
#function returns True and an error message if a criteria has not been met
#Return format is a Tuple(Bool, Error). "Error" is a string.
def check_house_number(house_number):

    if(house_number == ""):
        return ((True,"No house number given. Please fill in a house number.\n"))
    #Checking name length
    if(len(house_number) > 20):
        return (True,"House Number is longer than 20 characters. Please try again.\n")
        
    #House Number meets the criteria
    return (False, "")