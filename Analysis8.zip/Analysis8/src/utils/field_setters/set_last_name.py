import string
from utils.misc.clear_console import clear_console

#Sets Last Name
def set_last_name():
    thisScreen = True
    error = False
    error_msg = ""

    while(thisScreen):
        clear_console()
        if(error):
            print(error_msg)
        print("Please fill in the Last Name and press enter.")
        user_input = str(input("Input>>"))

        result = check_last_name(user_input)
        error = result[0]
        thisScreen = result[0]
        error_msg = result[1]

    return user_input

#Check if Last name contains the following rules:
# -Last name is not empty
# -Last name is not longer than 100 chars

#function returns False and no error message if last name is right
#function returns True and an error message if a criteria has not been met
#Return format is a Tuple(Bool, Error). "Error" is a string.
def check_last_name(lname):

    if(lname == ""):
        return ((True,"No last name given. Please fill in a name.\n"))
    #Checking name length
    if(len(lname) > 100):
        return (True,"Last name is longer than 100 characters. Please try again.\n")
        
    #Last name meets the criteria
    return (False, "")