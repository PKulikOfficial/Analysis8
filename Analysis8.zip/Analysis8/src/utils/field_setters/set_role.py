import string
from utils.misc.clear_console import clear_console

#Sets Role
def set_role():
    thisScreen = True
    error = False
    error_msg = ""

    while(thisScreen):
        clear_console()
        if(error):
            print(error_msg)
        print("Please input the number of the role of the account and press enter.\n1.Advisor\n2.System administrator")
        user_input = str(input("Input>>"))
        if(user_input == "1"):
            return "advisor"
        elif(user_input == "2"):
            return "sysadmin"
        else:
            error = True
            error_msg = "Invalid input. Please try again."