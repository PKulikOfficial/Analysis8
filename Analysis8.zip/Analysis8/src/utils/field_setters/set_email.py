import string
import re
from utils.misc.clear_console import clear_console

#Sets Email
def set_email():
    thisScreen = True
    error = False
    error_msg = ""

    while(thisScreen):
        clear_console()
        if(error):
            print(error_msg)
        print("Please fill in the Email and press enter.")
        user_input = str(input("Input>>"))

        result = check_email(user_input)
        error = result[0]
        thisScreen = result[0]
        error_msg = result[1]

    return user_input

#Check if Email contains the following rules:
# -Email is not empty
# -Email is not longer than 255 chars
# -Email meets the following regex: "[^@]+@[^@]+\.[^@]+"

#function returns False and no error message if email is right
#function returns True and an error message if a criteria has not been met
#Return format is a Tuple(Bool, Error). "Error" is a string.
def check_email(email):

    if(email == ""):
        return ((True,"No email given. Please fill in a name.\n"))
    #Checking name length
    if(len(email) > 255):
        return (True,"Email is longer than 255 characters. Please try again.\n")
    
    if(not re.fullmatch("[^@]+@[^@]+\.[^@]+", email)):
        return (True,"Invalid Email. Please try again.")
        
    #Email meets the criteria
    return (False, "")