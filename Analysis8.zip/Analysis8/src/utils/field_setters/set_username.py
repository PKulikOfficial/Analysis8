import string
from utils.misc.clear_console import clear_console
from utils.get.get_employees_all import get_employees_all

#Sets Username
def set_username(user):
    thisScreen = True
    error = False
    error_msg = ""

    while(thisScreen):
        clear_console()
        if(error):
            print(error_msg)
        print("Please fill in the Username and press enter.")
        user_input = str(input("Input>>"))

        result = check_username(user_input.lower(), user)
        error = result[0]
        thisScreen = result[0]
        error_msg = result[1]

    return user_input

#Check if username contains the following rules:
# -Username is not empty
# -Username start with a letter
# -Username is not shorter than 6 chars
# -Username is not longer than 10 chars
# -Username contains only the following characters: letters (a-z), numbers (0-9), underscores (_), apostrophes ('), and periods (.)
# -Username does not distinguish between lowercase and uppercase letters. (In set_username)
# -Username is unique in db

#function returns False and no error message if username is right
#function returns True and an error message if a criteria has not been met
#Return format is a Tuple(Bool, Error). "Error" is a string.
def check_username(username, user):
    #Checking username length
    if(username == ""):
        return (True,"No username given. Please fill in a name.\n")
    elif(username[0] not in (string.ascii_lowercase)):
        return (True,"Username must start with a letter. Please try again.\n")
    elif(len(username) < 6):
        return (True,"Username is shorter than 6 characters. Please try again.\n")
    elif(len(username) > 10):
        return (True,"Username is longer than 10 characters. Please try again.\n")
    
    allowed_chars = set(string.ascii_lowercase + string.digits + "_.'")
    for c in username:
        if(c not in allowed_chars):
            return (True, "Username may contain only the following characters: (a-z)(0-9) underscores (_), apostrophes ('), and periods (.)")
    
    usernames = get_employees_all(user[3])
    if(len(usernames) == 0):
        return (False, "")
    for u in usernames:
        if(u[4] == username):
            return (True, "Username already exists. Please try again.\n")
        
    #Username meets the criteria
    return (False, "")

#Check if username contains the following rules:
# -Username is not empty
# -Username start with a letter
# -Username is not shorter than 6 chars
# -Username is not longer than 10 chars
# -Username contains only the following characters: letters (a-z), numbers (0-9), underscores (_), apostrophes ('), and periods (.)
# -Username does not distinguish between lowercase and uppercase letters. (In set_username)

#function returns True if username is valid username that could be in the db
#function returns False if the username is not valid
def check_username_login(username):
    #Checking username length
    if(username == ""):
        return False
    elif(username[0] not in (string.ascii_lowercase)):
        return False
    elif(len(username) < 6):
        return False
    elif(len(username) > 10):
        return False
    
    allowed_chars = set(string.ascii_lowercase + string.digits + "_.'")
    for c in username:
        if(c not in allowed_chars):
            return False
        
    #Username meets the criteria
    return True