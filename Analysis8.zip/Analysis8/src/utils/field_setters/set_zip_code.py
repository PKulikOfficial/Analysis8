import string
from utils.misc.clear_console import clear_console

#Sets Zip Code
def set_zip_code():
    thisScreen = True
    error = False
    error_msg = ""

    while(thisScreen):
        clear_console()
        if(error):
            print(error_msg)
        print("Please complete the Zip code and press enter.")
        user_input = str(input("Input>>")).upper()

        result = check_zip_code(user_input)
        error = result[0]
        thisScreen = result[0]
        error_msg = result[1]

    return user_input

#Check if Zip code contains the following rules:
# -Zip code is not empty
# -Zip code input is not shorter than 8 digits.
# -Zip code input is not longer than 8 digits.
# -Zip code input has the following format DDDDXX.

#function returns False and no error message if last name is right
#function returns True and an error message if a criteria has not been met
#Return format is a Tuple(Bool, Error). "Error" is a string.
def check_zip_code(zip_code):

    if(zip_code == ""):
        return ((True,"No Zip code given. Please try again.\n"))    
    #Checking name length
    if(len(zip_code) > 6):
        return (True,"Zip code is longer than 6 digits. Please try again.\n")
    elif(len(zip_code) < 6):
        return (True,"Zip code is shorter than 6 digits. Please try again.\n")

    #Checking Format DDDDXX
    for c in zip_code[:4]:
        if(c not in string.digits):
            return(True,"Zip code must have the following format DDDDXX (D = Digit, X = Letter).Please try again\n")
    for c in zip_code[4:]:
        if(c not in string.ascii_uppercase):
            return(True,"Zip code must have the following format DDDDXX (D = Digit, X = Letter).Please try again\n")
    #Zip code meets the criteria
    return (False, "")