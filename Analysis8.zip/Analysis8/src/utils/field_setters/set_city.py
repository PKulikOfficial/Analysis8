import string
from utils.misc.clear_console import clear_console

#Sets City
def set_city():
    thisScreen = True
    error = False
    error_msg = ""

    while(thisScreen):
        clear_console()
        if(error):
            print(error_msg)
        print("Please input the number of the city and press enter.")
        print("1.Rotterdam\n2.Den Haag\n3.Amsterdam\n4.Leiden\n5.Utrecht\n6.Breda\n7.Eindhoven\n8.Delft\n9.Zwolle\n10.Nijmegen")
        user_input = str(input("Input>>"))

        if(user_input == "1"):
            return "Rotterdam"
        elif(user_input == "2"):
            return "Den Haag"
        elif(user_input == "3"):
            return "Amsterdam"
        elif(user_input == "4"):
            return "Leiden"
        elif(user_input == "5"):
            return "Utrecht"
        elif(user_input == "6"):
            return "Breda"
        elif(user_input == "7"):
            return "Eindhoven"
        elif(user_input == "8"):
            return "Delft"
        elif(user_input == "9"):
            return "Maastricht"
        elif(user_input == "10"):
            return "Nijmegen"
        else:
            error = True
            error_msg = "Invalid Input.Please try again.\n"
