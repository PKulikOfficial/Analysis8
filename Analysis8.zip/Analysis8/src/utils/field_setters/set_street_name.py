import string
from utils.misc.clear_console import clear_console

#Sets Street Name
def set_street_name():
    thisScreen = True
    error = False
    error_msg = ""

    while(thisScreen):
        clear_console()
        if(error):
            print(error_msg)
        print("Please fill in the Street Name and press enter.")
        user_input = str(input("Input>>"))

        result = check_street_name(user_input)
        error = result[0]
        thisScreen = result[0]
        error_msg = result[1]

    return user_input

#Check if Street name contains the following rules:
# -Street name is not empty
# -Street name is not longer than 70 chars

#function returns False and no error message if street name is right
#function returns True and an error message if a criteria has not been met
#Return format is a Tuple(Bool, Error). "Error" is a string.
def check_street_name(street_name):

    if(street_name == ""):
        return ((True,"No street name given. Please fill in a street name.\n"))
    #Checking name length
    if(len(street_name) > 70):
        return (True,"Street name is longer than 70 characters. Please try again.\n")
        
    #Street name meets the criteria
    return (False, "")