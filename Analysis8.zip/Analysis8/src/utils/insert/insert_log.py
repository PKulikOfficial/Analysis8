import sqlite3
import time
import os.path

from utils.encryption.encrypt import encryptTupleSpecificItems
from utils.encryption.encrypt import encrypt
from datetime import date

#[0] -> username
#[1] -> activity
#[2] -> additional_info
#[3] -> suspicious

#Adds log to db.
def insert_log(log):
    #Searching for DB file.
    if(os.path.exists('database/log.sqlite') == True):
        try:
            db = sqlite3.connect('database/log.sqlite')
            #Try updating to DB.
            try:    
                get_date = date.today().strftime("%d-%m-%Y")
                get_time = time.strftime("%H:%M:%S", time.localtime())
                e_log = encryptTupleSpecificItems(log, [1,2,3])
                add_log = db.cursor()
                add_log.execute("INSERT INTO log VALUES (:id, :username, :date, :time, :activity, :additional_info, :suspicious, :seen)", 
                    {
                        'id':                   None,
                        'username':             e_log[0],
                        'date':                 encrypt(get_date), 
                        'time':                 encrypt(get_time), 
                        'activity':             e_log[1],
                        'additional_info':      e_log[2], 
                        'suspicious':           e_log[3],
                        'seen':                 encrypt('NO')
                    }
                )
                db.commit()
                db.close()
            #Updating to DB failed. Raising error.
            except:
                db.close()
                print("Critical level error. Please contact the administrator.")
                input("Press enter to continue...\n") 
        except:
            print("Connecting to database failed.")
            input("Press enter to continue...\n")
    #No DB found. Raising error.
    else:
        print("Critical level error. Please contact the administrator.")
        input("Press enter to continue...\n")