import sqlite3
import time
import os.path

from utils.encryption.encrypt import encrypt
from utils.insert.insert_log import insert_log
from datetime import date
from utils.misc.check_suspicious_input import check_suspisious_input

#[0] -> First name
#[1] -> Last name
#[2] -> Street name
#[3] -> House number
#[4] -> Zip Code
#[5] -> City
#[6] -> Email
#[7] -> Mobile Phone
#[8] -> Membership ID

#Adds member to db.
def insert_member(member,username):
    check_suspisious_input(member, username)
    #Searching for DB file.
    if(os.path.exists('database/database.sqlite') == True):
        try:
            db = sqlite3.connect('database/database.sqlite')
            #Try adding to DB.
            try:
                get_date = date.today().strftime("%d-%m-%Y")
                add_member = db.cursor()
                add_member.execute("INSERT INTO member VALUES (:id, :membership_id, :first_name, :last_name, :registration_date, :email, :mobile_phone, :street_name, :house_number, :zip_code, :city  )",
                    {
                        'id':                   None,
                        'membership_id':        member[8],
                        'first_name':           encrypt(member[0]),
                        'last_name':            encrypt(member[1]),
                        'registration_date':    get_date,
                        'email':                encrypt(member[6]),
                        'mobile_phone':         encrypt(member[7]),  
                        'street_name':          encrypt(member[2]),
                        'house_number':         encrypt(member[3]),
                        'zip_code':             encrypt(member[4]),
                        'city':                 encrypt(member[5]),
                    }
                )
                db.commit()
                db.close()
                insert_log((f"{username}","ADD MEMBER",f"New member has been added. Membership ID: {member[8]}.","NO"))
                print("\nMember has been added to the database.")
                input("Press enter to continue...")
            #Adding to DB failed. Raising error.
            except:
                db.close()
                insert_log((f"{username}","ADD MEMBER",f"Failed to add new member. Table does not exist.","YES"))
                print("\nCritical level error. Please contact the administrator.")
                input("Press enter to continue...")                
        except:
            insert_log((f"{username}","ADD MEMBER",f"Failed to make a connection with the database.","NO"))
            print("\nConnecting to database failed.")
            input("Press enter to continue...")
    #No DB found. Raising error.
    else:
        insert_log((f"{username}","ADD MEMBER",f"Failed to add new member. Database does not exist.","YES"))
        print("\nCritical level error. Please contact the administrator.")
        input("Press enter to continue...")