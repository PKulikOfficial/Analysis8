import sqlite3
import time
import os.path

from utils.encryption.encrypt import encrypt
from datetime import date
from utils.insert.insert_log import insert_log
from utils.misc.check_suspicious_input import check_suspisious_input

#[0] -> First name
#[1] -> Last name
#[2] -> Username
#[3] -> Password
#[4] -> Role

#Adds employee to db.
def insert_employee(employee, username):
    check_suspisious_input(employee, username)
    #Searching for DB file.
    if(os.path.exists('database/database.sqlite') == True):
        try:
            db = sqlite3.connect('database/database.sqlite')
            #Try adding to DB.
            try:
                get_date = date.today().strftime("%d-%m-%Y")
                add_employee = db.cursor()
                add_employee.execute("INSERT INTO employee VALUES (:id, :first_name, :last_name, :registration_date, :username, :password, :role, :tmp_password)", 
                    {
                        'id':                  None,
                        'first_name':          encrypt(employee[0]),
                        'last_name':           encrypt(employee[1]), 
                        'registration_date':   get_date, 
                        'username':            encrypt(employee[2]),
                        'password':            encrypt(employee[3]), 
                        'role':                encrypt(employee[4]),
                        'tmp_password':        encrypt('YES')
                    }
                )
                db.commit()
                db.close()
                insert_log((f"{username}","ADD EMPLOYEE",f"Employee added with following username: {employee[2]}.","NO"))
                print("\nEmployee has been added to the database.")
                input("Press enter to continue...")
            #Adding to DB failed. Raising error.
            except:
                db.close()
                insert_log((f"{username}","ADD EMPLOYEE",f"Failed to add employee. Table does not exist.","YES"))
                print("\nCritical level error. Please contact the administrator.")
                input("Press enter to continue...")                
        except:
            insert_log((f"{username}","ADD EMPLOYEE",f"Failed to make a connection with the database.","NO"))
            print("\nConnecting to database failed.")
            input("Press enter to continue...")
    #No DB found. Raising error.
    else:
        insert_log((f"{username}","ADD EMPLOYEE",f"Failed to add employee. Database does not exist.","YES"))
        print("\nCritical level error. Please contact the administrator.")
        input("Press enter to continue...")