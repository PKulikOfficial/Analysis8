import sqlite3
import os.path

from utils.encryption.decrypt import decryptTupleListSpecificItems

#Gets all logs from database.
def get_logs():
    #Searching for DB file.
    if(os.path.exists('database/log.sqlite') == True):
        try:
            db = sqlite3.connect('database/log.sqlite')
            #Searching through DB.
            try:
                logs = db.cursor()
                logs.execute("SELECT * FROM log")
                result = logs.fetchall()
                db.close()
                return decryptTupleListSpecificItems(result,[1,2,3,4,5,6,7])
            #Searching through DB failed. Raising error.
            except:
                db.close()
                print("Failed to get logs.\n")   
                return []                
        except:
            print("Failed to get logs.\n")
            return []
    #No DB found. Raising error.
    else:
        print("Failed to get logs.\n")
        return []