import sqlite3
import os.path

from utils.encryption.decrypt import decryptTupleList
from utils.insert.insert_log import insert_log

#Gets the access for different functions for a chosen role.
def get_access_control(role, username):
    #Searching for DB file.
    if(os.path.exists('database/database.sqlite') == True):
        try:
            db = sqlite3.connect('database/database.sqlite')
            #Searching through DB.
            try:
                c = db.cursor()
                result = c.execute("SELECT function,access FROM access_control WHERE role=:role", {'role': role})
                result = c.fetchall()
                db.close()
                return decryptTupleList(result)
            except:
                db.close()
                insert_log((f"{username}","ACCESS CONTROL",f"Failed to get access control list. Table does not exist.","YES"))
                print("\nCritical level error. Please contact the administrator.")
                input("Press enter to continue...")                
        except:
            insert_log((f"{username}","ACCESS CONTROL",f"Failed to make a connection with the database.","NO"))
            print("\nConnecting to database failed.")
            input("Press enter to continue...")
    #No DB found. Raising error.
    else:
        insert_log((f"{username}","ACCESS CONTROL",f"Failed to get access control list. Database does not exist.","YES"))
        print("\nCritical level error. Please contact the administrator.")
        input("Press enter to continue...")            