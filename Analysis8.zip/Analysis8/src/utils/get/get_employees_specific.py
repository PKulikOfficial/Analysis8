import sqlite3
import os.path

from utils.encryption.decrypt import decryptTupleListSpecificItems
from utils.encryption.encrypt import encrypt
from utils.insert.insert_log import insert_log

#Gets all employees with a specific role.
def get_employees_specific(role, username):
    #Searching for DB file.
    if(os.path.exists('database/database.sqlite') == True):
        try:
            db = sqlite3.connect('database/database.sqlite')
            #Searching through DB.
            try:
                enc_role = encrypt(role)
                emp = db.cursor()
                emp.execute("SELECT id,first_name,last_name,registration_date,username,role FROM employee WHERE role=:role", {'role': enc_role})
                result = emp.fetchall()
                db.close()
                insert_log((f"{username}","GET EMPLOYEE",f"Looked through employee list","NO"))
                return decryptTupleListSpecificItems(result,[1,2,4,5])
            #Searching through DB failed. Raising error.
            except:
                db.close()
                insert_log((f"{username}","GET EMPLOYEE",f"Failed to look through employee list. Table does not exist.","YES"))
                print("Failed to get employees.\n")   
                return []                  
        except:
            insert_log((f"{username}","GET EMPLOYEE",f"Failed to make a connection with the database.","NO"))
            print("Failed to get employees.\n")
            return []            
    #No DB found. Raising error.
    else:
        insert_log((f"{username}","GET EMPLOYEE",f"Failed to look through employee list. Table does not exist.","YES"))
        print("Failed to get employees.\n")
        return []