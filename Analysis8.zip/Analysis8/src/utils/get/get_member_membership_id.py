import sqlite3
import os.path

from utils.encryption.decrypt import decryptTupleList
from utils.insert.insert_log import insert_log

#Gets all membership_ids
def get_member_membership_id(username):
    #Searching for DB file.
    if(os.path.exists('database/database.sqlite') == True):
        try:
            db = sqlite3.connect('database/database.sqlite')
            #Searching through DB.
            try:
                emp = db.cursor()
                emp.execute("SELECT membership_id FROM member")
                result = emp.fetchall()
                db.close()
                return decryptTupleList(result)
            #Searching through DB failed. Raising error.
            except:
                db.close()
                insert_log((f"{username}","GET MEM ID",f"Failed to look through member id list. Table does not exist.","YES"))
                print("Failed to get member id's.\n")   
                return []                
        except:
            insert_log((f"{username}","GET MEM ID",f"Failed to make a connection with the database.","NO"))
            print("Failed to get member id's.\n")
            return []
    #No DB found. Raising error.
    else:
        insert_log((f"{username}","GET MEM ID",f"Failed to look through member id list. Table does not exist.","YES"))
        print("Failed to get member id's.\n")
        return []
