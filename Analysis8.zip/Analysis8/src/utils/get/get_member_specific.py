import sqlite3
import os.path

from utils.encryption.decrypt import decryptTupleListSpecificItems
from utils.encryption.encrypt import encrypt
from utils.insert.insert_log import insert_log
from utils.misc.check_suspicious_input import check_suspisious_input

def get_member_specific(term, username):
    check_suspisious_input([term], username)

    #Searching for DB file.
    if(os.path.exists('database/database.sqlite') == True):
        try:
            db = sqlite3.connect('database/database.sqlite')
            #Searching through DB.
            try:
                not_enc = term
                term = encrypt(term)
                emp = db.cursor()
                emp.execute("""SELECT * FROM member WHERE 
                                    membership_id LIKE :not_enc OR
                                    first_name LIKE :term OR
                                    last_name LIKE :term OR
                                    registration_date LIKE :not_enc OR
                                    email LIKE :term OR
                                    mobile_phone LIKE :term OR
                                    street_name LIKE :term OR
                                    house_number LIKE :term OR
                                    zip_code LIKE :term OR
                                    city LIKE :term""", 
                                    {'term': '%'+term+'%', 'not_enc': '%'+not_enc+'%'}
                )
                result = emp.fetchall()
                db.close()
                return  decryptTupleListSpecificItems(result,[2,3,5,6,7,8,9,10])
            #Searching through DB failed. Raising error.
            except:
                db.close()
                insert_log((f"{username}","GET MEMBER",f"Failed to look through member list. Table does not exist.","YES"))
                print("Failed to get members.\n")   
                return []                
        except:
            insert_log((f"{username}","GET MEMBER",f"Failed to make a connection with the database.","NO"))
            print("Failed to get members.\n")
            return []
    #No DB found. Raising error.
    else:
        insert_log((f"{username}","GET MEMBER",f"Failed to look through member list. Table does not exist.","YES"))
        print("Failed to get members.\n")
        return []
    