#Dynamically assigns the correct menu value to the task.
def get_menu_value(options):
    menuValue = [None] * len(options)
    assign_menu_number = 1

    #Assign correct menu value to the tasks.
    for i in range(len(options)):
        if(options[i][1] == "True"):
            menuValue[i] = assign_menu_number
            assign_menu_number = assign_menu_number + 1 
    return menuValue