import sqlite3
import os.path

from utils.encryption.encrypt import encrypt

#Gets the count of suspicious logs that have not been seen yet by an administrator.
def get_logs_suspicious_not_seen():
    #Searching for DB file.
    if(os.path.exists('database/log.sqlite') == True):
        try:
            db = sqlite3.connect('database/log.sqlite')
            #Searching through DB.
            try:
                logs = db.cursor()
                no = encrypt("NO")
                yes = encrypt("YES")
                logs.execute("SELECT COUNT(suspicious) FROM log WHERE suspicious=:yes AND seen=:no", {'yes': yes, 'no': no})
                result = logs.fetchone()
                db.close()
                return result
           #Searching through DB failed. Raising error.
            except:
                db.close() 
                return "FAILED TO LOAD"                
        except:
            return "FAILED TO LOAD"
    #No DB found. Raising error.
    else:
        return "FAILED TO LOAD"