import sqlite3
import os.path

from utils.encryption.decrypt import decryptTupleListSpecificItems
from utils.insert.insert_log import insert_log

#Gets all members
def get_member_all(username):
    #Searching for DB file.
    if(os.path.exists('database/database.sqlite') == True):
        try:
            db = sqlite3.connect('database/database.sqlite')
            #Searching through DB.
            try:
                emp = db.cursor()
                emp.execute("SELECT * FROM member")
                result = emp.fetchall()
                db.close()
                insert_log((f"{username}","GET MEMBER",f"Looked through member list","NO"))
                return decryptTupleListSpecificItems(result,[2,3,5,6,7,8,9,10])
            #Searching through DB failed. Raising error.
            except:
                db.close()
                insert_log((f"{username}","GET MEMBER",f"Failed to look through member list. Table does not exist.","YES"))
                print("Failed to get members.\n")   
                return []                
        except:
            insert_log((f"{username}","GET MEMBER",f"Failed to make a connection with the database.","NO"))
            print("Failed to get members.\n")
            return []
    #No DB found. Raising error.
    else:
        insert_log((f"{username}","GET MEMBER",f"Failed to look through member list. Table does not exist.","YES"))
        print("Failed to get members.\n")
        return []