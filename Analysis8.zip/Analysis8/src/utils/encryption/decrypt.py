import string

def decrypt(text):
    shift = 3
    alphabet = ''.join([string.digits, string.ascii_lowercase, string.ascii_uppercase, string.punctuation])
    shifted_alphabet = alphabet[shift:] + alphabet[:shift]
    table = str.maketrans(shifted_alphabet, alphabet)
    return text.translate(table)

def decryptTuple(t):
    tmp = list(t)
    for i in range(len(tmp)):
        tmp[i] = decrypt(tmp[i])
    return tuple(tmp)

def decryptTupleSpecificItems(t,specific):
    tmp = list(t)
    for i in range(len(specific)):
        for j in range(len(tmp)):
            if(specific[i] == j):
                tmp[j] = decrypt(tmp[j])
    return tuple(tmp)

def decryptTupleList(li):
    for i in range(len(li)):
        li[i] = decryptTuple(li[i])
    return li

def decryptTupleListSpecificItems(li,specific):
    for i in range(len(li)):
        li[i] = decryptTupleSpecificItems(li[i],specific)
    return li