import string

def encrypt(text):
    shift = 3
    alphabet = ''.join([string.digits, string.ascii_lowercase, string.ascii_uppercase, string.punctuation])
    shifted_alphabet = alphabet[shift:] + alphabet[:shift]
    table = str.maketrans(alphabet, shifted_alphabet)
    return text.translate(table)

def encryptTuple(t):
    tmp = list(t)
    for i in range(len(tmp)):
        tmp[i] = encrypt(tmp[i])
    return tuple(tmp)

def encryptTupleSpecificItems(t,specific):
    tmp = list(t)
    for i in range(len(specific)):
        for j in range(len(tmp)):
            if(specific[i] == j):
                tmp[j] = encrypt(tmp[j])
    return tuple(tmp)

def encryptTupleList(li):
    for i in range(len(li)):
        li[i] = encryptTuple(li[i])
    return li

def encryptTupleListSpecificItems(li,specific):
    for i in range(len(li)):
        li[i] = encryptTupleSpecificItems(li[i],specific)
    return li

