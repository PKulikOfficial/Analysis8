import sqlite3
import os.path

from utils.insert.insert_log import insert_log
from utils.misc.check_suspicious_input import check_suspisious_input

#Deletes employee based on chosen id.
def delete_employee(id, employee, username):
    check_suspisious_input([id], username)
    #Searching for DB file.
    if(os.path.exists('database/database.sqlite') == True):
        try:
            db = sqlite3.connect('database/database.sqlite')
            #Try adding to DB.
            try:
                emp = db.cursor()
                emp.execute("DELETE FROM employee WHERE id=:id", {'id': id})
                db.commit()
                db.close()
                insert_log((f"{username}","DELETE EMPLOYEE",f"Employee deleted with following username: {employee}.","NO"))
                print("\nEmployee has been deleted from the database.")
                input("Press enter to continue...")
            #Adding to DB failed. Raising error.
            except:
                db.close()
                insert_log((f"{username}","DELETE EMPLOYEE",f"Failed to delete employee. Table does not exist.","YES"))
                print("\nCritical level error. Please contact the administrator.")
                input("Press enter to continue...")                
        except:
            insert_log((f"{username}","DELETE EMPLOYEE",f"Failed to make a connection with the database.","NO"))
            print("\nConnecting to database failed.")
            input("Press enter to continue...")
    #No DB found. Raising error.
    else:
        insert_log((f"{username}","DELETE EMPLOYEE",f"Failed to delete employee. Database does not exist.","YES"))
        print("\nCritical level error. Please contact the administrator.")
        input("Press enter to continue...")