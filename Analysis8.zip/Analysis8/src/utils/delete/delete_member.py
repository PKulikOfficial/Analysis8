import sqlite3
import os.path

from utils.insert.insert_log import insert_log
from utils.misc.check_suspicious_input import check_suspisious_input

#Deletes employee based on chosen id.
def delete_member(id, memid, username):
    check_suspisious_input([id], username)
    #Searching for DB file.
    if(os.path.exists('database/database.sqlite') == True):
        try:
            db = sqlite3.connect('database/database.sqlite')
            #Try adding to DB.
            try:
                mem = db.cursor()
                mem.execute("DELETE FROM member WHERE id=:id", {'id': id})
                db.commit()
                db.close()
                insert_log((f"{username}","DELETE MEMBER",f"Member deleted with following Membership ID: {memid}","NO"))
                print("\nMember has been deleted from the database.")
                input("Press enter to continue...")
            #Adding to DB failed. Raising error.
            except:
                db.close()
                insert_log((f"{username}","DELETE MEMBER",f"Failed to delete member. Table does not exist.","YES"))
                print("\nCritical level error. Please contact the administrator.")
                input("Press enter to continue...")                
        except:
            insert_log((f"{username}","DELETE MEMBER",f"Failed to make a connection with the database.","NO"))
            print("\nConnecting to database failed.")
            input("Press enter to continue...")
    #No DB found. Raising error.
    else:
        insert_log((f"{username}","DELETE MEMBER",f"Failed to delete member. Database does not exist.","YES"))
        print("\nCritical level error. Please contact the administrator.")
        input("Press enter to continue...")