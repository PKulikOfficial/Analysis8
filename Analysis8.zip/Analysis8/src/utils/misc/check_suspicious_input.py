import re
from utils.insert.insert_log import insert_log

def check_suspisious_input(inputs, username):
    for inp in inputs:
        #Checking DROP
        if(re.search(r'\bdrop\b', str(inp).lower()) != None):
            insert_log((f"{username}","SUSPICIOUS INPUT",f"Detected DROP in input field","YES"))
        
        #Checking ALTER
        if(re.search(r'\balter\b', str(inp).lower()) != None):
            insert_log((f"{username}","SUSPICIOUS INPUT",f"Detected ALTER in input field","YES"))
        
        #Checking SELECT
        if(re.search(r'\bselect\b', str(inp).lower()) != None):
            insert_log((f"{username}","SUSPICIOUS INPUT",f"Detected SELECT in input field","YES"))       

        #Checking for AND in the input
        if(re.search(r'\band\b', str(inp).lower()) != None):
            insert_log((f"{username}","SUSPICIOUS INPUT",f"Detected AND in input field","YES"))      

        #Checking for OR in the input  
        if(re.search(r'\bor\b', str(inp).lower()) != None):
            insert_log((f"{username}","SUSPICIOUS INPUT",f"Detected OR in input field","YES"))   
